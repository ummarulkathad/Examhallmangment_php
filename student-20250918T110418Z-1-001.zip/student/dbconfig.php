<?php
$server="localhost";
$db_user="root";
$db_pwd="";
$db_name="final";


$con=mysqli_connect($server,$db_user,$db_pwd);
if(!$con)
{
	
	echo "Connection failed";
}
$db=mysqli_select_db($con,$db_name);
if(!$db)
{
	
	echo "database not failed";
}

?>