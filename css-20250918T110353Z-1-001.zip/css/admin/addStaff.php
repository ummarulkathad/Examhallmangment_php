<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script type='text/javascript'>
  
 function put_uname()
 {
	 
	 stffid=document.getElementById("i2").value;
	 document.getElementById("i3").value=stffid;
 }
  
  
  </script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="time.png" alt="logo" style="width:60px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="adminpanel.php">Admin Panel</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addBranch.php">Add Branch</a>
    </li>
	<li class="nav-item active">
      <a class="nav-link" href="addStaff.php">Add Staff</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addStudent.php">Add Student</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addSubject.php">Add Student</a>
    </li>
	
	
	<li class="nav-item ">
      <a class="nav-link" href="../index.php">Logout</a>
    </li>
	
    
  </ul>
</nav>


<!-- Grid system-->
<div class="container">

			<div class="row">
			<div class="col-sm-4">
			<br>
		
					  <h4>Add Staff</h4>
					 <form role="form"  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
										<div class="form-group">
										<label  for="a">Staff Name</label>
										<input type="text" name="T1" autocomplete="off" id="i1" required="" class="form-control form-control-sm">
										</div>
										
										<div class="form-group">
										<label  for="b">Staff ID</label>
										<input type="text" name="T2" autocomplete="off" id="i2" required="" class="form-control form-control-sm" onblur="put_uname()";>
										</div>
										
										<div class="form-group">
										<label  for="c">Branch</label>
										<select class="form-control form-control-sm" name="D1" id="d1" required="">
										<?php
										
										
										include 'dbconfig.php';
										$q="select * from branch";
										$r=mysqli_query($con,$q);
										while($row=mysqli_fetch_array($r))
										{
											$bcode=$row["bcode"];
											$bname=$row["bname"];
											
											echo "<option value='".$bcode."'>".$bname."</option>";
											
										}										
										
										
										
										?>
										</select>
										</div>
										
										<div class="form-group">
										<label  for="d">User Name</label>
										<input type="text" name="T3" autocomplete="off" id="i3" required="" class="form-control form-control-sm" readonly>
										</div>
										
										<div class="form-group">
										<label  for="e">Password</label>
										<input type="password" name="T4" autocomplete="off" id="i4" required="" class="form-control form-control-sm">
										</div>
										
										<button type="submit" name="submit" class="btn btn-success">Add</button>
					 </form>
			</div>
			<div class="col-sm-8">
							<div class="table-responsive">
							  <table class="table">
								<tr>
								<th>Sl NO</th>
								<th>Staff Code</th>
								<th>Staff Name</th>
								<th>Branch</th>
								<th>action</th>
								</tr>
							 
						<?php
						
							include 'dbconfig.php';
							$slno=0;
									$q="select * from staff_details";
									$r=mysqli_query($con,$q);
									while($row=mysqli_fetch_array($r))
									{
										
										$staffid=$row["staffid"];
										$staffname=$row["staffname"];
										$branch=$row["branch"];
										
									$slno++;
									echo "<tr>";
									echo "<td>".$slno."</td>";
									echo "<td>".$staffid."</td>";
									echo "<td>".$staffname."</td>";
									echo "<td>".$branch."</td>";
									echo "<td><a href='deletestaff.php?id=".$staffid."'><img src='deleteicon.png' height='30' width='20'></a></td>";
									echo "<tr>";	
										
										
									}
									
									
									
						
						?>
						 </table>
							</div>
			
			</div>
			</div>
			<?php
								if(isset($_POST['submit'])) 
									
								{ 
									include 'dbconfig.php';
									$staffname=$_POST["T1"];
									$staffid=$_POST["T2"];//103
									$uname=$_POST["T3"];
									$password=$_POST["T4"];
									$branch=$_POST["D1"];
									
									
									$flag=0;
									
									$q="select staffid from staff_details";
									$r=mysqli_query($con,$q);
									while($row=mysqli_fetch_array($r))
									{
										$staffidfromdb=$row["staffid"];
										if($staffidfromdb==$staffid)
										{
											$flag=1;
										}
										
									}
									if($flag==1)
									{
										echo "<div class='alert alert-danger'>
										<strong>Error!!</strong> Given Data Already Exist.
										</div>";
										
									}
									else
									{
										$q="insert into staff_details values('$staffid','$staffname','$branch','$uname','$password','new','')";
										$r=mysqli_query($con,$q);
										if($r)
										{
											echo "<script> alert('Staff Details Sucessfully Added');
											window.location.href='addStaff.php';
											</script>";
											
										}
										else
										{
											echo "<div class='alert alert-danger'>
											<strong>Error!!</strong> Operation Failed
											</div>";
										}
									}
								}
			
			?>
</div>

</body>
</html>