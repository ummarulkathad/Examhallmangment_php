<?php

$staffid=$_REQUEST["id"];
include 'dbconfig.php';
$q="delete from staff_details where staffid='$staffid'";
$r=mysqli_query($con,$q);
if($r)
{
	
	echo "<script> alert('Deleted Successfully');
	window.location.href='addStaff.php';
	</script>";
	
}
else
{
	echo "<script> alert(' Operation Failed');
	window.location.href='addStaff.php';
	</script>";	
		
}
?>