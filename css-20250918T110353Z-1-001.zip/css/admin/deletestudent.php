<?php

$regno=$_REQUEST["id"];
include 'dbconfig.php';
$q="delete from student_details where regno='$regno'";
$r=mysqli_query($con,$q);
if($r)
{
	
	echo "<script> alert('Deleted Successfully');
	window.location.href='addStudent.php';
	</script>";
	
}
else
{
	echo "<script> alert(' Operation Failed');
	window.location.href='addStudent.php';
	</script>";	
		
}
?>