<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script type='text/javascript'>
  
 function put_regno()
 {
	 
	 regno=document.getElementById("i1").value;
	 document.getElementById("i3").value=regno;
	 document.getElementById("i4").value=regno;
 }
  
  
  </script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="time.png" alt="logo" style="width:60px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="adminpanel.php">Admin Panel</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addBranch.php">Add Branch</a>
    </li>
	<li class="nav-item ">
      <a class="nav-link" href="addStaff.php">Add Staff</a>
    </li>
	<li class="nav-item ">
      <a class="nav-link" href="addStudent.php">Add Student</a>
    </li>
	
	<li class="nav-item">
      <a class="nav-link" href="addSubject.php">Add Student</a>
    </li>
	
	<li class="nav-item ">
      <a class="nav-link" href="../index.php">Logout</a>
    </li>
	
    
  </ul>
</nav>


<!-- Grid system-->
<div class="container">

			<div class="row">
			<div class="col-sm-4">
			<br>
		
					  <h4>Add Student</h4>
					 <form role="form"  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
										<div class="form-group">
										<label  for="a">Regno</label>
										<input type="text" name="T1" autocomplete="off" id="i1" required="" class="form-control form-control-sm"  onblur="put_regno()";>
										</div>
										
										<div class="form-group">
										<label  for="b">Student Name</label>
										<input type="text" name="T2" autocomplete="off" id="i2" required="" class="form-control form-control-sm">
										</div>
										
										<div class="form-group">
										<label  for="c">Branch</label>
										<select class="form-control form-control-sm" name="D1" id="d1" required="">
										<?php
										
										
										include 'dbconfig.php';
										$q="select * from branch";
										$r=mysqli_query($con,$q);
										while($row=mysqli_fetch_array($r))
										{
											$bcode=$row["bcode"];
											$bname=$row["bname"];
											
											echo "<option value='".$bcode."'>".$bname."</option>";
											
										}										
										
										
										
										?>
										</select>
										</div>
										
										<div class="form-group">
										<label  for="c">Sem</label>
										<select class="form-control form-control-sm" name="D2" id="d2" required="">
										<option value="1">I</option>
										<option value="2">II</option>
										<option value="3">III</option>
										<option value="4">IV</option>
										<option value="5">V</option>
										<option value="6">VI</option>
										</select>
										</div>
										
										
										
										
										
										<div class="form-group">
										<label  for="d">User Name</label>
										<input type="text" name="T3" autocomplete="off" id="i3" required="" class="form-control form-control-sm" readonly>
										</div>
										
										<div class="form-group">
										<label  for="e">Password</label>
										<input type="password" name="T4" autocomplete="off" id="i4" required="" class="form-control form-control-sm" readonly>
										</div>
										
										<button type="submit" name="submit" class="btn btn-success">Add</button>
					 </form>
			</div>
			<div class="col-sm-8">
				
			
			</div>
			</div>
			<?php
								if(isset($_POST['submit'])) 
									
								{ 
									include 'dbconfig.php';
									$regno=strtoupper($_POST["T1"]);//497CS19001
									$sname=strtoupper($_POST["T2"]);//103
									$branch=$_POST["D1"];
									$sem=$_POST["D2"];
									$uname=$_POST["T3"];
									$pwd=$_POST["T4"];
									
									
					date_default_timezone_set("Asia/Calcutta");	
					
					$cdate=date('d-m-Y');//14-06-2022
					$ctime=date('h:i:sa');//02:41:36 AM
					$lastlogintime=$cdate." [ ".$ctime." ] ";   //14-06-2022 [ 02:43:36 ]
					
									$flag=0;
									
									$q="select regno from student_details";
									$r=mysqli_query($con,$q);
									while($row=mysqli_fetch_array($r))
									{
										$regnofromdb=$row["regno"];
										if($regnofromdb==$regno)
										{
											$flag=1;
										}
										
									}
									if($flag==1)
									{
										echo "<div class='alert alert-danger'>
										<strong>Error!!</strong> Given Data Already Exist.
										</div>";
										
									}
									else
									{
										$q="insert into student_details values('$regno','$sname','$branch','$sem','$uname','$pwd','new','$lastlogintime')";
										$r=mysqli_query($con,$q);
										if($r)
										{
											echo "<script> alert('Student Details Sucessfully Added');
											window.location.href='ads.php';
											</script>";
											
										}
										else
										{
											echo "<div class='alert alert-danger'>
											<strong>Error!!</strong> Operation Failed
											</div>";
										}
									}
								}
			
			?>
</div>

</body>
</html>