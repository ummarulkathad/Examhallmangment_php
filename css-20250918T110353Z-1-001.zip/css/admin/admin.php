<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
</head>
<body  background="313.jpg">

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="time.png" alt="logo" style="width:60px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="adminpanel.php"><font color='white'>Admin Panel</font></a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addBranch.php">Add Branch</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addStaff.php">Add Staff</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addStudent.php">Add Student</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addSubject.php">Add Subject</a>
    </li>
	
	
	<li class="nav-item ">
      <a class="nav-link" href="../index.php">Logout</a>
    </li>
	
    
  </ul>
</nav>


<!-- Grid system-->
<div class="container">

			Welcome to Admin panel

</div>

</body>
</html>