<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="time.png" alt="logo" style="width:60px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="adminpanel.php">Admin Panel</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addBranch.php">Add Branch</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addStaff.php">Add Staff</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addStudent.php">Add Student</a>
    </li>
	
		<li class="nav-item active">
       <a class="nav-link" href="addSubject.php">Add Subject</a>
    </li>
	
	<li class="nav-item ">
      <a class="nav-link" href="../index.php">Logout</a>
    </li>
	
    
  </ul>
</nav>


<!-- Grid system-->
<div class="container">

			<div class="row">
			<div class="col-sm-4">
			<br>
		
					  <h4>Add Subject</h4>
					 <form role="form"  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
										<div class="form-group">
										<label  for="sname">Subject Name</label>
										<input type="text" name="T1" autocomplete="off" id="i1" required="" class="form-control form-control-sm">
										</div>
										
										<div class="form-group">
										<label  for="scode">Subject Code</label>
										<input type="text" name="T2" autocomplete="off" id="i2" required="" class="form-control form-control-sm">
										</div>
										
										<button type="submit" name="submit" class="btn btn-success">Add</button>
					 </form>
			</div>
			<div class="col-sm-8">
							<div class="table-responsive">
							  <table class="table">
								<tr>
								<th>Sl NO</th>
								<th>Subject Name</th>
								<th>Subject code</th>
								<th>Action</th>
								</tr>
							 
						<?php
						
							include 'dbconfig.php';
							$slno=0;
									$q="select * from subject_details";
									$r=mysqli_query($con,$q);
									while($row=mysqli_fetch_array($r))
									{
										
										$snamefromdb=$row["sname"];
										$scodefromdb=$row["scode"];
										
									$slno++;
									echo "<tr>";
									echo "<td>".$slno."</td>";
									echo "<td>".$snamefromdb."</td>";
									echo "<td>".$scodefromdb."</td>";
									echo "<td><a href='deletesubject.php?id=".$scodefromdb."'><img src='deleteicon.png' height='30' width='20'></a></td>";
									echo "<tr>";	
										
										
									}
									
									
									
						
						?>
						 </table>
							</div>
			
			</div>
			</div>
			<?php
								if(isset($_POST['submit'])) 
									
								{ 
									include 'dbconfig.php';
									$sname=$_POST["T1"];
									$scode=$_POST["T2"];
									
									$sname=strtoupper($sname);
									$scode=strtoupper($scode);
									$flag=0;
									
									$q="select * from subject_details";
									$r=mysqli_query($con,$q);
									while($row=mysqli_fetch_array($r))
									{
										$snamefromdb=$row["sname"];
										$scodefromdb=$row["scode"];
										if($sname==$snamefromdb && $scode==$scodefromdb)
										{
											$flag=1;
										}
										
									}
									if($flag==1)
									{
										echo "<div class='alert alert-danger'>
										<strong>Error!!</strong> Given Data Already Exist.
										</div>";
										
									}
									else
									{
										$q="insert into subject_details values('$scode','$sname')";
										$r=mysqli_query($con,$q);
										if($r)
										{
											echo "<script> alert('Subject Details Sucessfully Added');
											window.location.href='addsubject.php';
											</script>";
											
										}
										else
										{
											echo "<div class='alert alert-danger'>
											<strong>Error!!</strong> Operation Failed
											</div>";
										}
									}
								}
			
			?>
</div>

</body>
</html>