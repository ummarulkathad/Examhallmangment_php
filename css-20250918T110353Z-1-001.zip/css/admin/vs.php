<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script type='text/javascript'>
  
 function put_regno()
 { 
	 regno=document.getElementById("i1").value;
	 document.getElementById("i3").value=regno;
	 document.getElementById("i4").value=regno;
 }
  
  
  </script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="time.png" alt="logo" style="width:60px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="adminpanel.php">Admin Panel</a>
    </li>
	<li class="nav-item">
      <a class="nav-link" href="addBranch.php">Add Branch</a>
    </li>
	<li class="nav-item ">
      <a class="nav-link" href="addStaff.php">Add Staff</a>
    </li>
	<li class="nav-item ">
      <a class="nav-link" href="addStudent.php">Add Student</a>
    </li>
	<li class="nav-item ">
      <a class="nav-link" href="addsubject.php">Add Subject</a>
    </li>
	<li class="nav-item dropdown active">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
      Student
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="ads.php">Add</a>
        <a class="dropdown-item" href="vs.php">View</a>        
      </div>
    </li>
	
	<li class="nav-item ">
      <a class="nav-link" href="../index.php">Logout</a>
    </li>
	
    
  </ul>
</nav>


<!-- Grid system-->
<div class="container">

			<div class="row">
			<div class="col-sm-2">
	
			</div>
			<div class="col-sm-8">
							<div class="table-responsive">
							  <table class="table">
								<tr>
								<th>Sl NO</th>
								<th>REG NO</th>
								<th>Name</th>
								<th>Branch</th>
								<th>SEM</th>
								<th>Action</th>
								</tr>
							 
						<?php
						
							include 'dbconfig.php';
							$slno=0;
									$q="select * from student_details";
									$r=mysqli_query($con,$q);
									while($row=mysqli_fetch_array($r))
									{
										
										$regno=$row["regno"];
										$sname=$row["sname"];
										$branch=$row["branch"];
										$sem=$row["sem"];
										
										
									$slno++;
									echo "<tr>";
									echo "<td>".$slno."</td>";
									echo "<td>".$regno."</td>";
									echo "<td>".$sname."</td>";
									echo "<td>".$branch."</td>";
									echo "<td>".$sem."</td>";
									echo "<td><a href='deletestudent.php?id=".$regno."'><img src='deleteicon.png' height='30' width='20'></a></td>";
									echo "<tr>";	
										
										
									}
									
									
									
						
						?>
						 </table>
							</div>
			
			</div>
			<div class="col-sm-2">
	
			</div>
			</div>
			
</div>

</body>
</html>