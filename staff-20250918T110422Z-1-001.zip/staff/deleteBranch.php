<?php

$bcode=$_REQUEST["id"];
include 'dbconfig.php';
$q="delete from branch where bcode='$bcode'";
$r=mysqli_query($con,$q);
if($r)
{
	
	echo "<script> alert('Deleted Successfully');
	window.location.href='addBranch.php';
	</script>";
	
}
else
{
	echo "<script> alert(' Operation Failed');
	window.location.href='addBranch.php';
	</script>";	
		
}
?>